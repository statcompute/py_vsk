# py_vsk/__init__.py

__version__ = "0.0.8"

from .py_vsk import *
